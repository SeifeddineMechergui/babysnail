<footer class="footer">

   <section class="grid">


      <div class="box">
         <h3>contact us</h3>
         <a href="tel:1234567890"><i class="fas fa-phone"></i> +216 24-286-285</a>
         <a href="tel:11122233333"><i class="fas fa-phone"></i> +216 24-286-285</a>
         <a href="mailto:shaikh@gmail.com"><i class="fas fa-envelope"></i>mechergui.seifeddine@yahoo.com</a>
         <a href="https://www.google.com/myplace"><i class="fas fa-map-marker-alt"></i>Sejnane - Bizerte - 7010 </a>
      </div>

      <div class="box">
         <h3>follow us</h3>
         <a href="#"><i class="fab fa-facebook-f"></i>facebook</a>
         <a href="#"><i class="fab fa-twitter"></i>twitter</a>
         <a href="#"><i class="fab fa-instagram"></i>instagram</a>
         <a href="#"><i class="fab fa-linkedin"></i>linkedin</a>
      </div>

   </section>
</footer>